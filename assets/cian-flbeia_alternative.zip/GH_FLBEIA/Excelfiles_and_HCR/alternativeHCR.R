
IcesHCR2<-function (stocks, advice, advice.ctrl, year, stknm, ...) {
  
  nyears <- ifelse(is.null(advice.ctrl[[stknm]][["nyears"]]), 
                   3, advice.ctrl[[stknm]][["nyears"]])
  wts.nyears <- ifelse(is.null(advice.ctrl[[stknm]][["wts.nyears"]]), 
                       3, advice.ctrl[[stknm]][["wts.nyears"]])
  fbar.nyears <- ifelse(is.null(advice.ctrl[[stknm]][["fbar.nyears"]]), 
                        3, advice.ctrl[[stknm]][["fbar.nyears"]])
  f.rescale <- ifelse(is.null(advice.ctrl[[stknm]][["f.rescale"]]), 
                      TRUE, advice.ctrl[[stknm]][["f.rescale"]])
  stk <- stocks[[stknm]]
  stk@harvest[stk@harvest < 0] <- 1e-05
  stk@catch.n[is.na(stk@catch.n)] <- 1e-06
  stk@landings.n[is.na(stk@landings.n)] <- 0
  stk@discards.n[is.na(stk@discards.n)] <- 1e-06
  stk@catch.n[stk@catch.n == 0] <- 1e-06
  stk@landings.n[stk@landings.n == 0] <- 1e-06
  stk@discards.n[stk@discards.n == 0] <- 0
  stk@catch <- computeCatch(stk)
  stk@landings <- computeLandings(stk)
  stk@discards <- computeDiscards(stk)
  ageStruct <- ifelse(dim(stk@m)[1] > 1, TRUE, FALSE)
  if (ageStruct == TRUE) {
    if (any(stk@catch[, tail(dimnames(stk@catch)$year, 3)] < 
            0.01)) {
      stk <- stf_correctSel(stk, nyears = 3, wts.nyears = wts.nyears, 
                            fbar.nyears = fbar.nyears, f.rescale = f.rescale)
    }
    else {
      stk <- stf(stk, nyears = 3, wts.nyears = wts.nyears, 
                           fbar.nyears = fbar.nyears, f.rescale = f.rescale)
    }
  }
  else {
    stk <- stfBD(stk, nyears = 3, wts.nyears = 3, fbar.nyears = 3)
  }
  ref.pts <- advice.ctrl[[stknm]]$ref.pts
  Cadv <- ifelse(advice.ctrl[[stknm]][["AdvCatch"]][year + 
                                                      1] == TRUE, "catch", "landings")
  iter <- dim(stk@m)[6]
  yrsnames <- dimnames(stk@m)[[2]]
  yrsnumbs <- as.numeric(yrsnames)
  assyrname <- yrsnames[year]
  assyrnumb <- yrsnumbs[year]
  if (ageStruct) 
    b.datyr <- ssb(stk)[, year - 1, drop = TRUE]
  else b.datyr <- (stk@stock.n * stk@stock.wt)[, year - 1, 
                                               drop = TRUE]
  #print(b.datyr)

  b.pos <- apply(matrix(1:iter, 1, iter), 2, function(i) findInterval(b.datyr[i], 
                                                                      ref.pts[c("Blim", "Btrigger"), i]))
 
  Ftg <- ifelse(b.pos == 0, 0, ifelse(b.pos == 1,0.000001, ref.pts['Fmsy',]))
 
  print(Ftg)
  int.yr <- advice.ctrl[[stknm]]$intermediate.year
  for (i in 1:iter) {
    if (is.na(Ftg[i]) | Ftg[i] == 0) {
      advice[["TAC"]][stknm, year + 1, , , , i] <- 0
   }
    
    int.yr <- ifelse(is.null(int.yr), "Fsq", int.yr)
    if (int.yr == "Fsq") 
      fwd.ctrl <- FLash::fwdControl(data.frame(year = c(0, 
                                                        1), val = c(1, Ftg[i]), quantity = c("f", "f"), 
                                               rel.year = c(-1, NA)))
    else fwd.ctrl <- FLash::fwdControl(data.frame(year = c(0, 
                                                           1), val = c(advice$TAC[stknm, year, drop = TRUE][i], 
                                                                       Ftg[i]), quantity = c("catch", "f")))
    fwd.ctrl@target$year <- fwd.ctrl@target$year + assyrnumb
    fwd.ctrl@target$rel.year <- fwd.ctrl@target$rel.year + 
      assyrnumb
    stki <- iter(stk, i)
    if (fwd.ctrl@target[fwd.ctrl@target$year == assyrnumb, 
                        "quantity"] == "catch") {
      k <- which(fwd.ctrl@target$year == assyrnumb)
      fwd.ctrl@target[k, "val"] <- advice$TAC[stknm, year, 
                                              , , , i]
      fwd.ctrl@trgtArray[k, "val", ] <- advice$TAC[stknm, 
                                                   year, , , , i]
    }
    if (dim(stki@m)[1] > 1) {
      sr.pars <- advice.ctrl[[stknm]]$sr$params
      sr.model <- advice.ctrl[[stknm]]$sr$model
      if (is.null(sr.pars)) {
        if (is.null(advice.ctrl[[stknm]]$sr$years)) 
          sr.yrs <- which(round(quantSums(stocks[[stknm]]@stock.n)) != 
                            0)[1]:(year - 1)
        else {
          y.rm <- as.numeric(advice.ctrl[[stknm]]$sr$years["y.rm"])
          nyrs <- as.numeric(advice.ctrl[[stknm]]$sr$years["num.years"])
          sr.yrs <- yrsnames[(year - y.rm - nyrs + 1):(year - 
                                                         y.rm)]
        }
        rec <- stki@stock.n[1, sr.yrs]
        ssb <- ssb(stki)[, sr.yrs]
       # ssb <- ssb(stki)[,sr.yrs] - ref.pts[ 'Btrigger',]
        rec.age <- as.numeric(dimnames(rec)[[1]])
        if (rec.age != 0) {
          rec <- rec[, -(1:rec.age), ]
          ssb <- ssb[, 1:(dim(ssb)[2] - rec.age), ]
        }
        if (sr.model != "geomean") 
          sr.pars <- try(params(fmle(FLSR(rec = rec, 
                                          ssb = ssb, model = sr.model))), silent = TRUE)
        if (class(sr.pars) == "try-error" | sr.model == 
            "geomean") {
          sr.model <- "geomean"
          sr.pars <- c(prod(c(rec))^(1/length(c(rec))))
          sr.pars <- FLPar(a = ifelse(is.na(sr.pars), 
                                      0, sr.pars))
        }
        sr1 <- sr.pars
      }
      else {
        if (i == 1) {
          sr1 <- iter(sr.pars, i)
        }
        sr1[] <- iter(sr.pars, i)[]
      }
      stki <- FLash::fwd(stki, ctrl = fwd.ctrl, sr = list(model = sr.model, 
                                                          params = sr1))
    }
    else {
      if (is.null(advice.ctrl[[stknm]]$growth.years)) 
        growth.years <- max(1, (year - 11)):(year - 1)
      else {
        y.rm <- as.numeric(advice.ctrl[[stknm]]$growth.years["y.rm"])
        nyrs <- as.numeric(advice.ctrl[[stknm]]$growth.years["num.years"])
        growth.years <- yrsnames[(year - y.rm - nyrs + 
                                    1):(year - y.rm)]
      }
      stki <- fwdBD(stki, fwd.ctrl, growth.years)
    }
    yy <- ifelse(slot(stki, Cadv)[, year + 1] == 0, 1e-06, 
                 slot(stki, Cadv)[, year + 1])
    advice[["TAC"]][stknm, year + 1, , , , i]<-(b.datyr[i]*(1-(exp(-0.25))))-((1-(exp(-0.25)))*49500)
    if (advice[["TAC"]][stknm, year + 1, , , , i] < 1)
      advice[["TAC"]][stknm, year + 1, , , , i]<-0.1
  }
  return(advice)
}

create.IcesHCR2.ctrl<-
function (resst, stkname, largs) 
{
  first.yr <- largs$first.yr
  last.yr <- largs$last.yr
  resst <- c(resst, nyears = 3, wts.nyears = 3, fbar.nyears = 3, 
             f.rescale = TRUE, ref.pts = NULL, AdvCatch = NULL, intermediate.year = "Fsq", 
             growth.years = NULL, first.yr = NULL, last.yr = NULL)
  resst$sr <- list(params = NULL, model = "geomean", years = NULL)
  ref.pts.stk <- largs[[paste("ref.pts", stkname, sep = ".")]]
  AdvCatch.stk <- largs[[paste("AdvCatch", stkname, sep = ".")]]
  cat("--------------------- NOTE ON ADVICE ------------------------------------------------------------------------------\n")
  cat("A default control for 'IcesHCR' HCR has been created for stock, ", 
      stkname, ".\n")
  cat("In the intermediate year fishing mortality equal to F statu quo.\n")
  cat("For recruitment or population growth in biomass a geometric mean of historic time series estimates will be used.\n")
  cat("Average of last 3 years used for biological parameters and fishing mortality.\n")
  if (is.null(ref.pts.stk)) {
    it <- ifelse(is.null(largs$iter), 1, largs$iter)
    warning("Reference points for stock, '", stkname, "' have not been specified in argument: ", 
            paste("ref.pts", stkname, sep = "."), ". \n -  A ref.pts element with empty reference points has been created. FILL IT BY HAND!!!!", 
            immediate. = TRUE)
    if (is.null(it)) 
      warning("iter argument is missing, iter = 1 will be used in the creation of ref.pts element, correct it if necessary.")
    ref.pts.stk <- matrix(NA, 3, it, dimnames = list(c("Blim", 
                                                       "Btrigger", "Fmsy"), 1:it))
    cat("------------------------------------------------------------------------------\n")
  }
  if (is.null(first.yr) | is.null(last.yr)) {
    stop("first.yr (first year with historic data) and last.yr (last year of projection) must be defined")
    cat("------------------------------------------------------------------------------\n")
  }
  if (is.null(AdvCatch.stk)) {
    AdvCatch.stk <- rep(FALSE, length(first.yr:last.yr))
    names(AdvCatch.stk) <- c(first.yr:last.yr)
    warning("Advice of ", stkname, " is FALSE by default, so the advice is given in terms of landings \n              ", 
            immediate. = TRUE)
    cat("------------------------------------------------------------------------------\n")
  }
  if (!is.matrix(ref.pts.stk) | !all(c("Blim", "Btrigger", 
                                       "Fmsy") %in% rownames(ref.pts.stk))) 
    stop(paste("ref.pts", stkname, sep = "."), " must be a matrix with dimension 3x(numb. of iterations) and rownames = c('Blim', 'Btrigger', 'Fmsy')")
  if (!is.null(largs$iter)) 
    if (largs$iter != dim(ref.pts.stk)[2]) 
      stop("Number of iterations in 'ref.pts.", stkname, 
           "' must be equal to the iterations specified in 'iter' argument.")
  resst$ref.pts <- ref.pts.stk
  resst$AdvCatch <- AdvCatch.stk
  return(resst)
}