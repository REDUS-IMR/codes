####Setup####
library(FLCore) 
library(FLAssess)
library(FLash)
library(FLFleet)
library(FLXSA)
#library(ggplotFL)
library(ggplot2)
library(FLBEIA) 
library(gridExtra)
#library(xlsx)
work_dir <- "/gpfs/gpfs0/home/home3/a22036/Excel files"
setwd<-work_dir
#######
##Names and time####
# Set Simulation parameters related with time
first.yr          <- 1
proj.yr           <- 2
last.yr           <- 40 
yrs <- c(first.yr=first.yr,proj.yr=proj.yr,last.yr=last.yr)
# Set names, age, dimensions 
fls   <- c('fl1')
stks <- c('stk1')
fl1.mets      <- c('met1')
fl1.met1.stks  <- c('stk1')
# all stocks the same
ni           <- 1000
it           <- 1:ni
ns             <- 1
# stock stk1
stk1.age.min    <- 1
stk1.age.max    <- 32
stk1.unit       <- 1  

#######
####Biological model####
#  Data: stk1_n.flq, m, spwn, fec, wt
#stock stk1- iteration selection for parameters
numbers<-read.csv( file = file.path(work_dir, 'stk1_n.csv'))
numbers<-numbers[-c(33:40), ]
stk1_n.flq     <- iter(as.FLQuant(numbers),it)
stk1_n.flq<- propagate(stk1_n.flq, iter = 1000)

mort <-read.csv( file = file.path(work_dir, 'stk1_m.csv'))
mort <-mort[-c(33:40), ]
stk1_m.flq     <- iter(as.FLQuant(mort),it)
stk1_m.flq<- propagate(stk1_m.flq, iter = 1000)

spwne <-read.csv( file = file.path(work_dir, 'stk1_spwn.csv'))
spwne <-spwne[-c(33:40), ]
stk1_spwn.flq     <- iter(as.FLQuant(spwne),it)
stk1_spwn.flq<- propagate(stk1_spwn.flq, iter = 1000)

fecm <-read.csv( file = file.path(work_dir, 'stk1_mat.csv'))
fecm <-fecm[-c(33:40), ]
stk1_fec.flq     <- iter(as.FLQuant(fecm),it)
stk1_fec.flq<- propagate(stk1_fec.flq, iter = 1000)
stk1_mat.flq   <- stk1_fec.flq

wts <-read.csv( file = file.path(work_dir, 'stk1_wt.csv'))
wts <-wts[-c(33:40), ]
stk1_wt.flq     <- iter(as.FLQuant(wts),it)
stk1_wt.flq<- propagate(stk1_wt.flq, iter = 1000)
#stk1_mat.flq[] <- 1
#min and max age, plus group age
stk1_range.iter      <- 1
stk1_range.min       <- 1
stk1_range.max       <- 30
stk1_range.plusgroup <- 30 #
stk1_range.minyear   <- 1
stk1_range.minfbar   <- 10 #
stk1_range.maxfbar   <- 30 #
# Projection biols: weight,fecundity,mortality and spawning 
stk1_biol.proj.avg.yrs  <- c(1:1)
# Create the object
stks.data <- list(stk1=ls(pattern="^stk1"))
##biols    <- create.biols.data(yrs,ns,ni,stks.data)
biols    <- create.biols.data(yrs,ns,ni,stks.data)


#######
###BH model####
stk1_sr.model        <- 'bevholt'
stk1_params.n        <- 3
stk1_params.array   <- xtabs2(data~param+year+season+iter, 
                              data=read.csv(file = file.path(work_dir, 'stk1_params_BH.csv')), 
                              exclude=NULL,na.action=na.pass)[,,,it,drop=F] 
stk1_params.name     <- c('a','b','c')
fdata <- read.csv(file = file.path(work_dir, 'stk1_params_BH.csv'))
fdata<- fdata[fdata$year<41,]
fdata[which(fdata$param=='a'),7]<- 7800000
fdata[which(fdata$param=='b'),7]<-8500
fdata<-lapply(fdata, rep.int, times=1000)
fdata<-as.data.frame(fdata)
fdata$iter<-rep(1:1000,times=1, each=120)
head(fdata)
tail(fdata)
str(fdata)
fdata[,7]<-array(unlist(fdata[,7]))
#######
##### Medium magnitude recruitment####
set.seed(4.3332)
ikl<-replicate(n = 4, runif(40000, 0, 10), simplify = FALSE )
randa<-ikl[[4]]
# FLBEIA input object: SRs
# Initialize `rcalc`
rcalc <- 0
result <- vector("list", 40000)
for(i in 1:40000) {
  dad <- fdata[which(fdata$param=='a'),7]
  rcalc[i] <- randa[i]
  if(rcalc[i]>9){
    (y<-dad[i]*5.5)
    result[i]<-y
    result
  } else{(x<-dad[i]*0.5)
    result[i]<-x
    result
  }
}
#result
bindcolumn<-cbind(result)
newcolumn<-as.data.frame.array(bindcolumn)
fdata[which(fdata$param=='a'),7]<-newcolumn
fdata[,7]<-array(unlist(fdata[,7]))
tail(fdata)
#stk1_params.array<-iter(as.FLQuant(fdata),it)
str(fdata)
str(stk1_params.array)
stk1_params.array<-xtabs2(data~param+year+season+iter, 
                          data=fdata, 
                          exclude=NULL,na.action=na.pass)[,,,it,drop=F] 

#stk1_params.array<-iter(as.FLQuant(stk1_params.array))
##### rest of sr model#####
stk1_rec.flq         <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'stk1_rec.csv'))),it)
stk1_rec.flq[,1]         <- 7800000
stk1_rec.flq<- propagate(stk1_rec.flq, iter = 1000)
stk1_ssb.flq        <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'stk1_ssb.csv'))),it)
stk1_ssb.flq[,1]     <-136000
stk1_ssb.flq          <-propagate(stk1_ssb.flq, iter = 1000)
stk1_uncertainty.flq <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'stk1_uncertainty.csv'))),it)
stk1_uncertainty.flq <- read.csv(file = file.path(work_dir, 'stk1_uncertainty.csv'))
stk1_uncertainty.flq <- stk1_uncertainty.flq[stk1_uncertainty.flq$year<41,]
stk1_uncertainty.flq <-iter(as.FLQuant(stk1_uncertainty.flq),it)
stk1_uncertainty.flq <-  propagate(stk1_uncertainty.flq, iter = 1000)
#stk1_uncertainty.flq <- propagate(stk1_uncertainty.flq, iter=100)
stk1_proportion.flq  <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'stk1_proportion.csv'))),it)
stk1_proportion.flq <- read.csv(file = file.path(work_dir, 'stk1_proportion.csv'))
stk1_proportion.flq <- stk1_proportion.flq[stk1_proportion.flq$year<41,]
stk1_proportion.flq <-iter(as.FLQuant(stk1_proportion.flq),it)
stk1_proportion.flq <-  propagate(stk1_proportion.flq, iter = 1000)
#stk1_proportion.flq  <- propagate(stk1_proportion.flq,iter=100)
stk1_prop.avg.yrs    <- ac(1:1)
stk1_timelag.matrix  <- matrix(c(1,1),nrow=2,ncol=1, dimnames = list(c('year', 'season'),'all'))
# FLBEIA input object: SRs
stks.data <- list(stk1=ls(pattern="^stk1")) 
SRs      <- create.SRs.data(yrs,ns,ni,stks.data)
####Fleet model####
# Data per fleet
#    effort, crewshare, fcost, capacity
# Data per fleet and metier
#    effshare, vcost
# Data per fleet, metier and stock
#    landings.n, discards.n,landings.wt, discards.wt, landings, discards, landings.sel, discards.sel, price

fl1_effort.flq        <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'fl1_effort.csv'))),it)
fl1_effort.flq        <- propagate(fl1_effort.flq, iter=1000)
fl1_capacity.flq      <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'fl1_capacity.csv'))),it) 
fl1_capacity.flq      <- propagate(fl1_capacity.flq, iter=1000)
fl1_fcost.flq         <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'fl1_fcost.csv'))),it) 
fl1_fcost.flq          <- propagate(fl1_fcost.flq, iter=1000)
fl1_crewshare.flq     <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'fl1_crewshare.csv'))),it) 
fl1_crewshare.flq     <- propagate(fl1_crewshare.flq, iter=1000)
fl1.met1_effshare.flq  <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'fl1.met1_effshare.csv'))),it) 
fl1.met1_effshare.flq        <- propagate(fl1.met1_effshare.flq, iter=1000)
fl1.met1.stk1_landings.n.flq <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'fl1.met1.stk1_landings.n.csv'))),it)
fl1.met1.stk1_landings.n.flq        <- propagate(fl1.met1.stk1_landings.n.flq, iter=1000)
fl1.met1.stk1_landings.n.flq  <- fl1.met1.stk1_landings.n.flq[-c(33:40),]
fl1.met1.stk1_discards.n.flq <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'fl1.met1.stk1_discards.n.csv'))),it)
fl1.met1.stk1_discards.n.flq        <- propagate(fl1.met1.stk1_discards.n.flq, iter=1000)
fl1.met1.stk1_discards.n.flq   <- fl1.met1.stk1_discards.n.flq[-c(33:40),]
fl1.met1.stk1_catch.q.flq    <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'fl1.met1.stk1_catch.q.csv')))  ,it)
fl1.met1.stk1_catch.q.flq        <- propagate(fl1.met1.stk1_catch.q.flq, iter=1000)
fl1.met1.stk1_catch.q.flq    <- fl1.met1.stk1_catch.q.flq [-c(33:40),]
# Projection
#         fleets: fl1
fl1_proj.avg.yrs           <- c(1:1)
fl1.met1_proj.avg.yrs       <- c(1:1)   
fl1.met1.stk1_proj.avg.yrs   <- c(1:1)   
# create fleets object
fls.data <- list(fl1=ls(pattern="^fl1")) 
fleets   <- create.fleets.data(yrs,ns,ni,fls.data,stks.data)
sim.yrs  <- as.character(first.yr:last.yr) 
burnin.yr = 25
sim.yrs1  <- as.character(first.yr:burnin.yr)
sim.yrs2  <- as.character((burnin.yr+1):last.yr)
fleets[['fl1']]@metiers[['met1']]@catches$stk1@landings.sel[1:10, sim.yrs, ] <- 0.01
fleets[['fl1']]@metiers[['met1']]@catches$stk1@landings.sel[10:30,sim.yrs, ] <- 1

#fleets[['fl1']]@metiers[['met1']]@catches$stk1@landings.sel[,sim.yrs1,]<-1
fleets[['fl1']]@metiers[['met1']]@effshare[,sim.yrs1,] <- 1
fleets[['fl1']]@metiers[['met1']]@effshare[,sim.yrs2,] <- 1
fleets[['fl1']]@metiers[['met1']]@catches$stk1@catch.q[10:30,1:40]<-0.1
#######
###advice:TAC/TAE/quota.share####
stk1_advice.TAC.flq         <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'stk1_advice.tac.csv'))),it)
stk1_advice.TAC.flq <-stk1_advice.TAC.flq[,1:40] 
stk1_advice.TAC.flq[,1:40] <- 20000
stk1_advice.TAC.flq<- propagate(stk1_advice.TAC.flq, iter=1000)
stk1_advice.quota.share.flq <- iter(as.FLQuant(read.csv(file = file.path(work_dir, 'stk1_advice.quota.share.csv'))),it)
stk1_advice.quota.share.flq <-stk1_advice.quota.share.flq[,1:40] 
stk1_advice.quota.share.flq[,1:40] <- 1
stk1_advice.quota.share.flq<- propagate(stk1_advice.quota.share.flq, iter=1000)
stk1_advice.avg.yrs         <- c(1:1)
# create advice object
stks.data <- list(stk1=ls(pattern="^stk1")) 
advice   <- create.advice.data(yrs,ns,ni,stks.data,fleets)
#####
###Controls####
###controls settings for initial and final year of projection
main.ctrl           <- list()
main.ctrl$sim.years <- c(initial = proj.yr, final = last.yr)
#######controls the biological operating model- age-structured growth model
growth.model     <- c('ASPG')
biols.ctrl       <- create.biols.ctrl (stksnames=stks,growth.model=growth.model)
####flts.ctrl
n.fls.stks <-1
fls.stksnames <-"stk1"
effort.models <-"SMFB"
effort.restr.fl1 <-"stk1"
restriction.fl1 <-"catch"
catch.models <-"CobbDouglasAge"
capital.models <-"fixedCapital"
flq.stk1 <-FLQuant(dimnames =list(age ="all",year =first.yr:last.yr,unit =stk1.unit,season =1:ns,iter =1:ni))
fleets.ctrl <-create.fleets.ctrl(fls =fls,n.fls.stks =n.fls.stks,fls.stksnames =fls.stksnames,effort.models =effort.models,catch.models =catch.models,capital.models =capital.models,flq =flq.stk1,effort.restr.fl1 =effort.restr.fl1,restriction.fl1 =restriction.fl1)
fleets.ctrl$fl1$stk1$discard.TAC.OS <-FALSE
fleets.ctrl$fl1$restriction <-"landings"
fleets.ctrl$catch.threshold[,1:25]<-0.9
fleets.ctrl$catch.threshold[,25:40]<-0.9
#fleets.ctrl$catch.threshold[,25:35]<-0.25
#fleets.ctrl$catch.threshold[,35:45]<-0.03
#fleets.ctrl$catch.threshold[,45:55]<-0.06
#fleets.ctrl$catch.threshold[,55:65]<-0.03
#fleets.ctrl$catch.threshold[,65:75]<-0.06
#fleets.ctrl$catch.threshold[,75:85]<-0.03
#fleets.ctrl$catch.threshold[,85:100]<-0.06
##indices
indices <- NULL
######
source('/gpfs/gpfs0/home/home3/a22036/Excel files/alternativeHCR.R')
IcesHCR2
#==============================================================================
#  Section 13:      ICES advice.ctrl
#==============================================================================
HCR.models <-c("IcesHCR2")
ref.pts.stk1 <-matrix(rep(c(0,112500,0.01),3),3, ni,dimnames =list(c("Blim","Btrigger","Fmsy"),1:ni))
advice.ctrl <-create.advice.ctrl(stksnames =stks,HCR.models =HCR.models,ref.pts.stk1 =ref.pts.stk1,first.yr =first.yr,last.yr =last.yr)
advice.ctrl[['stk1']]$nyears<-40
advice.ctrl[['stk1']]$fbar.nyears<- 1
advice.ctrl[['stk1']]$intermediate.year<-0.01
advice.ctrl[['stk1']]$wts.nyears<-1
advice.ctrl[["stk1"]][["sr"]] <-list()
advice.ctrl[["stk1"]][["sr"]][["model"]] <-"geomean"
advice.ctrl[["stk1"]][["sr"]][["years"]] <-c(y.rm =100,num.years =1)
advice.ctrl$stk1$AdvCatch <-rep(TRUE,length(first.yr:last.yr))#TRUE advice in catches, FALSE advice in landingsnames(advice.ctrl$stk1$AdvCatch) <-as.character((first.yr:last.yr))

advice.ctrl[['stk1']]$f.rescale


###Assessment model####
##Defines the assessment model for each stock
assess.models <-"NoAssessment"
assess.ctrl <-create.assess.ctrl(stksnames =stks,assess.models =assess.models)
assess.ctrl[["stk1"]]$work_w_Iter <-TRUE
##with no assessment model, management advice is based on observed population
stkObs.models <-"perfectObs"
flq.stk1 <-FLQuant(dimnames =list(age ="all",year =first.yr:last.yr,unit =stk1.unit,season =1:ns,iter =1:ni))
obs.ctrl <-create.obs.ctrl(stksnames =stks,stkObs.models =stkObs.models,flq.stk1 =flq.stk1)
#######
###Covariates####
####BDs/covars/covars.ctrl
covars.ctrl      <- NULL
BDs       <- NULL
covars    <- NULL
######
###FLBEIA RUN#####

##Run the operating model
start<-Sys.time()
s0 <- FLBEIA(biols = biols, SRs = SRs, BDs = BDs, fleets=fleets, covars = covars, 
             indices = indices, advice = advice, main.ctrl = main.ctrl, 
             biols.ctrl = biols.ctrl, fleets.ctrl = fleets.ctrl, 
             covars.ctrl = covars.ctrl, obs.ctrl = obs.ctrl, 
             assess.ctrl = assess.ctrl, advice.ctrl = advice.ctrl) 

#'#Results for FLBEIA
names(s0)
stk1.mp <- s0$stocks[['stk1']]
stk1.om <- FLBEIA:::perfectObs(s0$biols[['stk1']], s0$fleets, year = dim(s0$biols[['stk1']]@n)[2])
fin<-Sys.time()
start
fin
######
#####save####
saveRDS(s0,"/gpfs/gpfs0/home/home3/a22036/output/NOVPOMER_112_01.rds" )
######

